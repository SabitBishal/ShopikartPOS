<?php

namespace Nwidart\Modules\Exceptions;

class FileAlreadyExistException extends \Exception
{
}
